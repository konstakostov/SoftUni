from project.services.base_service import BaseService


class SecondaryService(BaseService):
    def __init__(self, name: str) -> None:
        super().__init__(name, capacity=15)

    # TODO
    def details(self):
        pass
