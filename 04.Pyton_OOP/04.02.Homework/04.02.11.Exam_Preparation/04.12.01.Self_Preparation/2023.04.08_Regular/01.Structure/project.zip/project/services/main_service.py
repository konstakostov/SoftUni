from project.services.base_service import BaseService


class MainService(BaseService):
    def __init__(self, name: str) -> None:
        super().__init__(name, capacity=30)

    # TODO
    def details(self):
        pass
