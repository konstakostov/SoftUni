class RobotsManagingApp:
    robots = []
    services = []

    # TODO
    def add_service(self, service_type: str, name: str):
        pass

    # TODO
    def add_robot(self, robot_type: str, name: str, kind: str, price: float):
        pass

    # TODO
    def add_robot_to_service(self, robot_name: str, service_name: str):
        pass

    # TODO
    def remove_robot_from_service(self, robot_name: str, service_name: str):
        pass

    # TODO
    def feed_all_robots_from_service(self, service_name: str):
        pass

    # TODO
    def service_price(self, service_name: str):
        pass

    # TODO
    def __str__(self):
        pass

