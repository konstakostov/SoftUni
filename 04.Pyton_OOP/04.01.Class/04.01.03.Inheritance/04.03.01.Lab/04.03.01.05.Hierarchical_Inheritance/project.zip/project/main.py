from project.dog import Dog
from project.cat import Cat

d = Dog()
c = Cat()

print(c.meow())
print(eat())

print(d.bark())
print(eat())
