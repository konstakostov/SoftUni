from project import Motorcycle


class CrossMotorcycle(Motorcycle):
    pass
