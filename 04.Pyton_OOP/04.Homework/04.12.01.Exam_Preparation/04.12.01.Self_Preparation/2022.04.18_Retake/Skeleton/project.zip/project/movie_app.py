from project.movie_specification.movie import Movie


class MovieApp:
    def __init__(self):
        self.movies_collection: list = []
        self.users_collection: list = []

    def register_user(self, username: str, age: int):
        pass

    def upload_movie(self, username: str, movie: object):
        pass

    def edit_movie(self, username: str, movie: object, **kwargs):
        pass

    def delete_movie(self, username: str, movie: object):
        pass

    def like_movie(self, username: str, movie: object):
        pass

    def dislike_movie(self, username: str, movie: object):
        pass

    def display_movies(self):
        pass

    def __str__(self):
        pass
